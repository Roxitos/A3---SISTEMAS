package com.banco.a3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A3GolpeBancoApplication {

	public static void main(String[] args) {
		SpringApplication.run(A3GolpeBancoApplication.class, args);
	}

}
