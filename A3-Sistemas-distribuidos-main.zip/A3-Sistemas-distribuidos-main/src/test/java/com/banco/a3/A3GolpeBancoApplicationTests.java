package com.banco.a3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A3GolpeBancoApplicationTests {

	@Test
	void contextLoads() {
	}

}
